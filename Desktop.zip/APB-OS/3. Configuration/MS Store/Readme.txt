How to enable Microsoft Store?

1. Go to Services & Drivers folder and set Windows Services & Drivers and then restart pc
2. After installation apps/games go again to Services & Drivers folder and set APB-OS Services & Drivers

IMPORTANT: Remember to use nsudo