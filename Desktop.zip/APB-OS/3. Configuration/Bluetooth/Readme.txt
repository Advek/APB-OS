As for the drivers, not all of them work. I know CSR 4.0 works for sure, but they have a menu like in win7.
You have to check what they work for yourself, but I prefer CSR 4.0 because they certainly work

dsc.gg/apbos