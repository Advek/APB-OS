If you have problems with your network, use the files below

dsc.gg/apbos