Use the file provided below if you see the following errors:
- Missing VCRUNTIME.dll
- Missing MSVCP.dll
- Memory Could Not Be Read
- Memory Could Not Be Written

How to Fix?
- Remove all Visual C++ Redistributables.
- Go to Support >> Troubleshooting >> Visual C++ Redistributable >> VCredist >> install_all.bat

dsc.gg/apbos